#include "cf_stub.h"

cf_request_handle_t _p0_request_0;
cf_request_handle_t _p0_request_1;
cf_request_handle_t _p0_request_2;
cf_request_handle_t _p0_request_3;
cf_request_handle_t _p0_request_4;
cf_request_handle_t _p0_request_5;
cf_request_handle_t _p0_request_6;
cf_request_handle_t _p0_request_7;
cf_request_handle_t _p0_request_8;
cf_request_handle_t _p0_request_9;

unsigned int _p0_dataflow_1_async_4_num_b;
unsigned int _p0_dataflow_1_async_3_num_b;
unsigned int _p0_dataflow_1_async_2_num_b;
unsigned int _p0_dataflow_1_async_1_num_b;
unsigned int _p0_dataflow_1_noasync_num_b;

