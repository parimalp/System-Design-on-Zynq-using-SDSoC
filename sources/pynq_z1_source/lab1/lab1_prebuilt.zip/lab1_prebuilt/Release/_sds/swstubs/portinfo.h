#ifndef _SDS_PORTINFO_H
#define _SDS_PORTINFO_H
/* File: C:/xup/SDSoC/pynq_z1_platform_source/pynq_z1/pynq_z1_1.sdk/lab1_prebuilt/Release/_sds/p0/.cf_work/portinfo.h */
#ifdef __cplusplus
extern "C" {
#endif

struct _p0_swblk_dataflow {
  cf_port_send_t cmd_dataflow;
  cf_port_send_t a;
  cf_port_receive_t b;
};

extern struct _p0_swblk_dataflow _p0_swinst_dataflow_1;
void _p0_cf_framework_open(int);
void _p0_cf_framework_close(int);

#ifdef __cplusplus
};
#endif
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
};
#endif /* extern "C" */
#endif /* _SDS_PORTINFO_H_ */
