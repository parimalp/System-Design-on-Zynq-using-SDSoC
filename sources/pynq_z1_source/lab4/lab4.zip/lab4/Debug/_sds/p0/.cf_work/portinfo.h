#ifdef __cplusplus
extern "C" {
#endif

void _p0_cf_framework_open(int);
void _p0_cf_framework_close(int);

#ifdef __cplusplus
};
#endif
