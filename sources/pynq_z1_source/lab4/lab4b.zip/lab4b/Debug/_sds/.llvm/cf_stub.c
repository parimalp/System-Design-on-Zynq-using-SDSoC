#include "cf_stub.h"

cf_request_handle_t _p0_request_0;
cf_request_handle_t _p0_request_1;

unsigned int _p0_rgb_2_gray_1_noasync_num_gray;

