#ifdef __cplusplus
extern "C" {
#endif

struct _p0_swblk_rgb_2_gray {
  cf_port_send_t cmd_rgb_2_gray;
  cf_port_send_t color;
  cf_port_receive_t gray;
};

extern struct _p0_swblk_rgb_2_gray _p0_swinst_rgb_2_gray_1;
void _p0_cf_framework_open(int);
void _p0_cf_framework_close(int);

#ifdef __cplusplus
};
#endif
