#ifdef __cplusplus
extern "C" {
#endif

struct _p0_swblk_dataflow {
  cf_port_send_t cmd_dataflow;
  cf_port_send_t a;
  cf_port_receive_t b;
};

extern struct _p0_swblk_dataflow _p0_swinst_dataflow_1;
void _p0_cf_framework_open(int);
void _p0_cf_framework_close(int);

#ifdef __cplusplus
};
#endif
