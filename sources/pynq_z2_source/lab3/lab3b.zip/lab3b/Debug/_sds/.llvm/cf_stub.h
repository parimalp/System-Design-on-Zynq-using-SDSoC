#ifndef STUBS_H_
#define STUBS_H_

#include "cf_lib.h"
#include "sds_lib.h"
#include "portinfo.h"

extern cf_request_handle_t _p0_request_0;
extern cf_request_handle_t _p0_request_1;

extern unsigned int _p0_sobel_filter_1_noasync_num_output_r;



#endif
