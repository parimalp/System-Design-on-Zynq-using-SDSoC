#ifndef STUBS_H_
#define STUBS_H_

#include "cf_lib.h"
#include "sds_lib.h"
#include "portinfo.h"

#include "sds_trace.h"

extern cf_request_handle_t _p0_request_0;
extern cf_request_handle_t _p0_request_1;

extern unsigned int _p0_rgb_2_gray_1_noasync_num_gray;



#endif
