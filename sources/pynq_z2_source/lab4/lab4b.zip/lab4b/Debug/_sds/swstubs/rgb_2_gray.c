#include "lab_design.h"
#include "rgb_2_gray.h"

//Reference https://www.mathworks.com/help/matlab/ref/rgb2gray.html for
//the values
void rgb_2_gray(uint32_t color[2073600], uint8_t gray[2073600]) {

	int i, j;
	int index;
	uint32_t red, green, blue;
	uint32_t thisPixel;

	for (i = 0; i < FRAME_HEIGHT; i++) {
		for (j = 0; j < FRAME_WIDTH; j++) {
//#ifdef OPTIMIZE_RGB_2_GRAY
#ifndef SUPPRESS_RGB_2_GRAY_OPTIMIZATION
#pragma AP PIPELINE II = 1
#endif
			index = (i * FRAME_WIDTH + j);

			thisPixel = color[index];
			red = (uint32_t) getRed(thisPixel);
			green = (uint32_t) getGreen(thisPixel);
			blue = (uint32_t) getBlue(thisPixel);

			uint16_t gr = (uint16_t)((red * 298 + green * 587 + blue * 114) >> 10); //Divide by 1024 (should be 1000 but not using floating point)

			gray[index] = (uint8_t) gr;
		}
	}
}

#include "cf_stub.h"
#ifdef __cplusplus
extern "C" {
#endif
void _p0_rgb_2_gray_1_noasync(uint32_t color[2073600], uint8_t gray[2073600]);
#ifdef __cplusplus
}
#endif
void _p0_rgb_2_gray_1_noasync(uint32_t color[2073600], uint8_t gray[2073600])
{
  int start_seq[1];
  start_seq[0] = 0;
  cf_request_handle_t _p0_swinst_rgb_2_gray_1_cmd;
  sds_trace(4000, EVENT_START); //ID:4000 Name:_p0_rgb_2_gray_1_noasync-cmdSend
  cf_send_i(&(_p0_swinst_rgb_2_gray_1.cmd_rgb_2_gray), start_seq, 1 * sizeof(int), &_p0_swinst_rgb_2_gray_1_cmd);
  sds_trace(4000, EVENT_STOP); //ID:4000 Name:_p0_rgb_2_gray_1_noasync-cmdSend
  cf_set_trace_wait_tag(_p0_swinst_rgb_2_gray_1_cmd, 3999); //ID:3999 Name:_p0_rgb_2_gray_1_noasync-cmdWait
  cf_wait(_p0_swinst_rgb_2_gray_1_cmd);

  sds_trace(3998,EVENT_START); //ID:3998 Name:_p0_rgb_2_gray_1_noasync:color-send
  cf_send_i(&(_p0_swinst_rgb_2_gray_1.color), color, 8294400, &_p0_request_0);
  sds_trace(3998,EVENT_STOP); //ID:3998 Name:_p0_rgb_2_gray_1_noasync:color-send
  cf_set_trace_wait_tag(_p0_request_0, 3997);//ID:3997 Name:_p0_rgb_2_gray_1_noasync:color-wait

  sds_trace(3996,EVENT_START); //ID:3996 Name:_p0_rgb_2_gray_1_noasync:gray-receive
  cf_receive_i(&(_p0_swinst_rgb_2_gray_1.gray), gray, 2073600, &_p0_rgb_2_gray_1_noasync_num_gray, &_p0_request_1);
  sds_trace(3996,EVENT_STOP); //ID:3996 Name:_p0_rgb_2_gray_1_noasync:gray-receive
  cf_set_trace_wait_tag(_p0_request_1, 3995);//ID:3995 Name:_p0_rgb_2_gray_1_noasync:gray-wait

  cf_wait(_p0_request_0);
  cf_wait(_p0_request_1);
}



