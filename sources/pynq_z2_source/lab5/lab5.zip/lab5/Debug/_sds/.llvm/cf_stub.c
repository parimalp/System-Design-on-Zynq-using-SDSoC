#include "cf_stub.h"

cf_request_handle_t _p0_request_0;
cf_request_handle_t _p0_request_1;

unsigned int _p0_sharpen_filter_1_noasync_num_output_r;

